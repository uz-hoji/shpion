import asyncio
import base64
import hashlib
import hmac
import json
import os
import secrets
import sqlite3
import time
from pathlib import Path
from urllib.parse import urlencode

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart
from aiogram.types import (
    Message, InlineKeyboardMarkup, InlineKeyboardButton,
    ReplyKeyboardMarkup, KeyboardButton, WebAppInfo,
)
import uvicorn

load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
BOT_USERNAME = os.getenv("BOT_USERNAME", "").strip().lstrip("@")
APP_URL = os.getenv("APP_URL", "").rstrip("/")
DB_PATH = os.getenv("DATABASE_PATH", "smart_access.db")
if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN is missing. Copy .env.example to .env and set it.")

bot = Bot(BOT_TOKEN)
dp = Dispatcher()
api = FastAPI(title="Smart Access API")
STATIC = Path(__file__).parent / "app" / "static"
api.mount("/static", StaticFiles(directory=STATIC), name="static")


def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with db() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS requests (
            token TEXT PRIMARY KEY, owner_id INTEGER NOT NULL, owner_name TEXT NOT NULL,
            kind TEXT NOT NULL, target_id INTEGER, created_at INTEGER NOT NULL,
            expires_at INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'pending'
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS results (
            id INTEGER PRIMARY KEY AUTOINCREMENT, token TEXT NOT NULL,
            kind TEXT NOT NULL, value TEXT NOT NULL, created_at INTEGER NOT NULL
        )""")


def get_request(token):
    with db() as c:
        return c.execute("SELECT * FROM requests WHERE token=?", (token,)).fetchone()


def create_request(owner_id, owner_name, kind):
    token = secrets.token_urlsafe(18)
    now = int(time.time())
    with db() as c:
        c.execute(
            "INSERT INTO requests(token,owner_id,owner_name,kind,created_at,expires_at) VALUES(?,?,?,?,?,?)",
            (token, owner_id, owner_name, kind, now, now + 86400),
        )
    return token


def save_result(token, kind, value):
    with db() as c:
        c.execute("INSERT INTO results(token,kind,value,created_at) VALUES(?,?,?,?)",
                  (token, kind, value, int(time.time())))
        c.execute("UPDATE requests SET status='completed' WHERE token=?", (token,))


def validate_init_data(init_data: str):
    """Validate Telegram Web App initData using the official HMAC procedure."""
    if not init_data:
        raise HTTPException(401, "Telegram session missing. Open this Mini App from Telegram.")
    from urllib.parse import parse_qsl
    values = dict(parse_qsl(init_data, keep_blank_values=True))
    received_hash = values.pop("hash", None)
    if not received_hash:
        raise HTTPException(401, "Invalid Telegram session.")
    data_check = "\n".join(f"{k}={v}" for k, v in sorted(values.items()))
    secret_key = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
    calculated = hmac.new(secret_key, data_check.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(calculated, received_hash):
        raise HTTPException(401, "Telegram session verification failed.")
    try:
        user = json.loads(values.get("user", "{}"))
        user_id = int(user["id"])
    except Exception:
        raise HTTPException(401, "Telegram user information is missing.")
    auth_date = int(values.get("auth_date", "0"))
    if int(time.time()) - auth_date > 86400:
        raise HTTPException(401, "Telegram session expired. Reopen the Mini App.")
    return user_id, user


def current_user(request: Request):
    return validate_init_data(request.headers.get("X-Telegram-Init-Data", ""))


def request_link(token):
    return f"https://t.me/{BOT_USERNAME}?start=req_{token}"


async def notify_owner(row, text):
    try:
        await bot.send_message(row["owner_id"], text)
    except Exception:
        pass


@dp.message(CommandStart())
async def start(message: Message):
    parts = (message.text or "").split(maxsplit=1)
    arg = parts[1] if len(parts) > 1 else ""
    if arg.startswith("req_"):
        token = arg[4:]
        row = get_request(token)
        if not row or row["expires_at"] < int(time.time()) or row["status"] != "pending":
            await message.answer("Bu havola muddati tugagan yoki bekor qilingan.")
            return
        if row["target_id"] and row["target_id"] != message.from_user.id:
            await message.answer("Bu so'rov boshqa Telegram foydalanuvchisi uchun bog'langan.")
            return
        with db() as c:
            c.execute("UPDATE requests SET target_id=? WHERE token=?",
                      (message.from_user.id, token))
        kind = row["kind"]
        labels = {"phone": "telefon raqami", "location": "joylashuv", "camera": "kamera orqali olingan surat"}
        intro = (f"🔐 Rozilik so'rovi\n\n{row['owner_name']} sizdan {labels[kind]}ni ulashishni so'ramoqda.\n"
                 "Ulashish ixtiyoriy. Rad etsangiz hech qanday ma'lumot yuborilmaydi.")
        if kind == "phone":
            kb = ReplyKeyboardMarkup(keyboard=[[KeyboardButton(text="📱 Telefon raqamimni ulashish", request_contact=True)]],
                                     resize_keyboard=True, one_time_keyboard=True)
            await message.answer(intro, reply_markup=kb)
        elif kind == "location":
            kb = ReplyKeyboardMarkup(keyboard=[[KeyboardButton(text="📍 Joylashuvimni ulashish", request_location=True)]],
                                     resize_keyboard=True, one_time_keyboard=True)
            await message.answer(intro, reply_markup=kb)
        else:
            kb = InlineKeyboardMarkup(inline_keyboard=[[
                InlineKeyboardButton(text="📷 Roziman — kamerani ochish",
                                     web_app=WebAppInfo(url=f"{APP_URL}/?mode=camera&token={token}"))
            ]])
            await message.answer(intro, reply_markup=kb)
        return

    dash = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="🚀 Open Smart Access", web_app=WebAppInfo(url=APP_URL + "/"))
    ]])
    await message.answer(
        "✨ Smart Access\n\nBoshqaruv panelini ochish uchun quyidagi tugmani bosing.\n"
        "Havolalar faqat aniq rozilik asosida ma'lumot yuboradi.",
        reply_markup=dash
    )


@dp.message(F.contact)
async def receive_contact(message: Message):
    contact = message.contact
    if contact.user_id != message.from_user.id:
        await message.answer("Faqat o'zingizning kontakt raqamingizni yuboring.")
        return
    with db() as c:
        row = c.execute("""SELECT * FROM requests WHERE target_id=? AND kind='phone'
            AND status='pending' AND expires_at>? ORDER BY created_at DESC LIMIT 1""",
            (message.from_user.id, int(time.time()))).fetchone()
    if not row:
        await message.answer("Faol telefon so'rovi topilmadi.")
        return
    save_result(row["token"], "phone", contact.phone_number)
    await notify_owner(row, f"📱 Telefon raqami rozilik bilan yuborildi:\n{contact.phone_number}")
    await message.answer("Rahmat. Telefon raqamingiz so'rov egasiga yuborildi.",
                         reply_markup={"remove_keyboard": True})


@dp.message(F.location)
async def receive_location(message: Message):
    loc = message.location
    with db() as c:
        row = c.execute("""SELECT * FROM requests WHERE target_id=? AND kind='location'
            AND status='pending' AND expires_at>? ORDER BY created_at DESC LIMIT 1""",
            (message.from_user.id, int(time.time()))).fetchone()
    if not row:
        await message.answer("Faol joylashuv so'rovi topilmadi.")
        return
    value = json.dumps({"latitude": loc.latitude, "longitude": loc.longitude})
    save_result(row["token"], "location", value)
    await notify_owner(row, f"📍 Joylashuv rozilik bilan yuborildi:\n"
                       f"Latitude: {loc.latitude}\nLongitude: {loc.longitude}\n"
                       f"https://maps.google.com/?q={loc.latitude},{loc.longitude}")
    await message.answer("Rahmat. Joylashuvingiz so'rov egasiga yuborildi.",
                         reply_markup={"remove_keyboard": True})


@api.get("/")
async def index():
    return FileResponse(STATIC / "index.html")


@api.get("/health")
async def health():
    return {"status": "ok", "app": "Smart Access"}


@api.post("/api/requests")
async def new_request(request: Request):
    user_id, user = current_user(request)
    body = await request.json()
    kind = body.get("kind")
    if kind not in {"phone", "location", "camera"}:
        raise HTTPException(400, "Unsupported request type.")
    token = create_request(user_id, user.get("first_name", "Telegram user"), kind)
    return {"token": token, "url": request_link(token), "kind": kind, "expires_in": 86400}


@api.get("/api/requests")
async def list_requests(request: Request):
    user_id, _ = current_user(request)
    with db() as c:
        rows = c.execute("""SELECT token,kind,created_at,expires_at,status FROM requests
            WHERE owner_id=? ORDER BY created_at DESC LIMIT 50""", (user_id,)).fetchall()
    return [dict(r) for r in rows]


@api.post("/api/requests/{token}/cancel")
async def cancel_request(token: str, request: Request):
    user_id, _ = current_user(request)
    with db() as c:
        row = c.execute("SELECT owner_id FROM requests WHERE token=?", (token,)).fetchone()
        if not row or row["owner_id"] != user_id:
            raise HTTPException(404, "Request not found.")
        c.execute("UPDATE requests SET status='cancelled' WHERE token=?", (token,))
    return {"ok": True}


@api.post("/api/camera/{token}")
async def camera_upload(token: str, request: Request):
    user_id, _ = current_user(request)
    row = get_request(token)
    if not row or row["kind"] != "camera" or row["status"] != "pending":
        raise HTTPException(404, "Camera request is not active.")
    if row["expires_at"] < int(time.time()) or row["target_id"] != user_id:
        raise HTTPException(403, "This request is expired or belongs to another user.")
    body = await request.json()
    image_data = body.get("image", "")
    if not image_data.startswith("data:image/") or len(image_data) > 8_000_000:
        raise HTTPException(400, "Invalid image.")
    try:
        header, encoded = image_data.split(",", 1)
        raw = base64.b64decode(encoded, validate=True)
    except Exception:
        raise HTTPException(400, "Could not read image.")
    if len(raw) > 5_000_000:
        raise HTTPException(413, "Image is too large.")
    from aiogram.types import BufferedInputFile
    await bot.send_photo(row["owner_id"], BufferedInputFile(raw, filename="smart-access-photo.jpg"),
                         caption="📷 Foydalanuvchi rozilik bilan surat yubordi.")
    save_result(token, "camera", "photo sent")
    return {"ok": True}


async def run():
    init_db()
    if not APP_URL.startswith("https://"):
        print("WARNING: APP_URL should be a public HTTPS URL for Telegram Mini Apps.")
    config = uvicorn.Config(api, host="0.0.0.0", port=8000, log_level="info")
    server = uvicorn.Server(config)
    await asyncio.gather(server.serve(), dp.start_polling(bot))


if __name__ == "__main__":
    asyncio.run(run())
