# Smart Access — Telegram bot + Mini App

A consent-first Telegram project. The owner creates a separate, expiring request link for
**phone**, **location**, or **camera**. The recipient sees who created the request and
what will be shared, then explicitly chooses whether to share it.

## Important privacy behavior
- No silent collection, background tracking, or hidden camera access.
- Phone and location use Telegram's native `request_contact` / `request_location` buttons.
- Camera capture starts only after the recipient presses **Enable camera** and grants the
  browser/Telegram permission. The recipient previews and presses **Send photo**.
- Camera permission is not a guarantee that a device has a front/rear camera; the browser
  controls availability.
- Requests expire after 24 hours and can be cancelled by the owner.
- The app validates Telegram Mini App `initData` on the server for dashboard and camera
  submissions. Do not disable this validation in production.

## Stack
- Python 3.11+
- Aiogram 3 (Telegram bot)
- FastAPI (API + static Mini App hosting)
- SQLite (simple self-hosted storage)
- Telegram Web Apps SDK + vanilla TypeScript-free HTML/CSS/JS frontend

## 1. Create the bot
1. Open `@BotFather` in Telegram and run `/newbot`.
2. Copy the bot token.
3. Set the bot's username in `.env`.
4. Set the Mini App URL with BotFather (`/setmenubutton`) to your HTTPS domain,
   or configure a Main Mini App. The bot also sends a Web App button for the dashboard.

## 2. Configure and run
```bash
python -m venv .venv
# Windows PowerShell:
.venv\\Scripts\\Activate.ps1
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
copy .env.example .env   # Windows; edit .env
# Linux/macOS: cp .env.example .env

python main.py
```
The server listens on `0.0.0.0:8000`. Set `APP_URL` to the public HTTPS address that
points to this server. Telegram Mini Apps require HTTPS. For local development, use a
trusted HTTPS tunnel and set that URL in `.env`.

## 3. How to use
1. Owner opens the bot and presses `/start`.
2. Press **Open dashboard** in the bot or menu button.
3. Choose Phone, Location, or Camera. The Mini App creates a unique link.
4. Share the link with the intended recipient.
5. Recipient opens the bot deep link. The bot explains the requested data and who will
   receive it. The recipient must press the explicit share button.
6. The result is sent only to the owner who created that request.

## Deployment notes
- Keep `.env` private. Never commit the bot token.
- Use HTTPS and a persistent disk for SQLite, or migrate to PostgreSQL for production.
- Run one bot polling process per token.
- Configure backups, retention/deletion, rate limits, and monitoring before public launch.
- `APP_URL` must be reachable by Telegram clients and must not contain a trailing slash.
