const tg = window.Telegram?.WebApp;
if (tg) { tg.ready(); tg.expand(); }
const initData = tg?.initData || "";
const user = tg?.initDataUnsafe?.user;
const headers = {"Content-Type":"application/json","X-Telegram-Init-Data":initData};
const $ = id => document.getElementById(id);
const params = new URLSearchParams(location.search);
const mode = params.get("mode");
const token = params.get("token");
let stream = null, captured = null;

if (user) {
  $("username").textContent = user.first_name || "foydalanuvchi";
  $("avatar").textContent = (user.first_name || "U").slice(0,1).toUpperCase();
}
function toast(message) {
  const el=$("toast"); el.textContent=message; el.classList.add("show");
  setTimeout(()=>el.classList.remove("show"),2600);
}
async function api(url, options={}) {
  const response=await fetch(url,{...options,headers:{...headers,...options.headers}});
  const data=await response.json().catch(()=>({}));
  if(!response.ok) throw new Error(data.detail || "So'rov bajarilmadi");
  return data;
}
async function createLink(kind) {
  try {
    const result=await api("/api/requests",{method:"POST",body:JSON.stringify({kind})});
    const box=$("created"); box.classList.remove("hidden");
    const labels={phone:"Telefon raqami",location:"Joylashuv",camera:"Kamera"};
    box.innerHTML=`<strong>✓ ${labels[kind]} uchun havola yaratildi</strong><div class="linkline"><input readonly value="${result.url}" id="shareUrl"><button id="copyLink">Nusxalash</button></div><p class="hint">Havolani faqat ma'lumotini ulashishga rozi bo'lgan odamga yuboring. 24 soatdan keyin muddati tugaydi.</p>`;
    $("copyLink").onclick=async()=>{await navigator.clipboard.writeText(result.url);toast("Havola nusxalandi");};
    loadHistory();
  } catch(e){toast(e.message);}
}
document.querySelectorAll("[data-kind]").forEach(b=>b.addEventListener("click",()=>createLink(b.dataset.kind)));
async function loadHistory(){
  try {
    const rows=await api("/api/requests");
    $("history").innerHTML=rows.length?rows.map(r=>{
      const labels={phone:"Telefon raqami",location:"Joylashuv",camera:"Kamera"};
      const date=new Date(r.created_at*1000).toLocaleString();
      return `<div class="history-row"><div><strong>${labels[r.kind]}</strong><small>${date}</small></div><span class="state ${r.status==="cancelled"?"cancelled":""}">${r.status==="pending"?"Kutilmoqda":r.status==="completed"?"Yakunlangan":"Bekor qilingan"}</span></div>`;
    }).join(""):'<div class="empty">So\\'rovlar hali mavjud emas.</div>';
  } catch(e){$("history").innerHTML='<div class="empty">Tarixni ko\\'rish uchun Mini Appni Telegram ichidan oching.</div>';}
}
$("refresh").onclick=loadHistory;
if(mode==="camera" && token){
  $("dashboard").classList.add("hidden"); $("camera").classList.remove("hidden");
  $("enable").onclick=startCamera;
  $("capture").onclick=capturePhoto;
  $("send").onclick=sendPhoto;
  $("retake").onclick=()=>{captured=null;$("preview").classList.add("hidden");$("video").classList.remove("hidden");$("capture").classList.remove("hidden");$("send").classList.add("hidden");$("retake").classList.add("hidden");};
  $("facing").onchange=()=>{if(stream)startCamera();};
  $("back").onclick=()=>{stopCamera();history.back();};
} else {loadHistory();}

async function startCamera(){
  try{
    stopCamera();
    stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:$("facing").value},audio:false});
    $("video").srcObject=stream; $("video").classList.remove("hidden");$("preview").classList.add("hidden");
    $("capture").classList.remove("hidden");$("send").classList.add("hidden");$("retake").classList.add("hidden");
    $("cameraStatus").textContent="Kamera yoqildi. Suratga olish uchun tugmani bosing.";
  }catch(e){$("cameraStatus").textContent="Kameraga ruxsat berilmadi yoki kamera mavjud emas. Qurilma ruxsatlarini tekshiring.";}
}
function capturePhoto(){
  const video=$("video"),canvas=$("canvas");
  if(!video.videoWidth){toast("Kamera tasviri hali tayyor emas");return;}
  canvas.width=video.videoWidth;canvas.height=video.videoHeight;
  canvas.getContext("2d").drawImage(video,0,0);
  captured=canvas.toDataURL("image/jpeg",.86);
  $("preview").src=captured;$("preview").classList.remove("hidden");video.classList.add("hidden");
  $("capture").classList.add("hidden");$("send").classList.remove("hidden");$("retake").classList.remove("hidden");
  stopCamera();$("cameraStatus").textContent="Surat ko'rib chiqildi. Yuborish uchun tasdiqlang.";
}
async function sendPhoto(){
  if(!captured)return;
  try{
    await api("/api/camera/"+encodeURIComponent(token),{method:"POST",body:JSON.stringify({image:captured})});
    $("cameraStatus").textContent="Surat yuborildi. Rahmat!";
    $("send").classList.add("hidden");$("retake").classList.add("hidden");
  }catch(e){$("cameraStatus").textContent=e.message;}
}
function stopCamera(){if(stream){stream.getTracks().forEach(t=>t.stop());stream=null;}}
window.addEventListener("pagehide",stopCamera);
